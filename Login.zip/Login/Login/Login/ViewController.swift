//
//  ViewController.swift
//  Login
//
//  Created by Filipe Malachias Resende on 2019-08-21.
//  Copyright © 2019 Malachias. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var UserNameTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    
    @IBOutlet var loginButton: UIButton!
    @IBOutlet var forgotUserNameButton: UIButton!
    @IBOutlet var forgotPasswordButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        UserNameTextField.text = ""
        passwordTextField.text = ""
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // gets called right before the segue happens
        // - pass data (information) from this VC to destination VC
        if segue.identifier == "loginSuccess"
        {
            let destVC = segue.destination as? SuccessViewController
            destVC?.message = "Welcome, \(UserNameTextField.text!)"
        } else if segue.identifier == "forgotUserName"
        {
            let destVC = segue.destination as? SuccessViewController
            destVC?.message = "User Name: "
        } else if segue.identifier == "forgotPassword"
        {
            let destVC = segue.destination as? SuccessViewController
            destVC?.message = "Password: "
        }
    
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "loginSuccess" {
            if UserNameTextField.text == "" || passwordTextField.text == "" {
                return false
            }
        }
        return true
    }
    
    @IBAction func loginButton(_ sender: UIButton)
    {
    }
    
    @IBAction func forgotUserNameButton(_ sender: UIButton)
    {
    }
    
    @IBAction func forgotPasswordButton(_ sender: UIButton) {
    }
    
}

