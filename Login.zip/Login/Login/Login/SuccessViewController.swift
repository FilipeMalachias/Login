//
//  SuccessViewController.swift
//  Login
//
//  Created by Filipe Malachias Resende on 2019-08-22.
//  Copyright © 2019 Malachias. All rights reserved.
//

import UIKit

class SuccessViewController: UIViewController {

    var message: String!
    
    @IBOutlet var messageLabel: UILabel! {
        didSet {
            messageLabel.text = message
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
